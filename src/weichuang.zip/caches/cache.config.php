<?php
define('DIY_BASE_NAME', '');
define('DIY_BRAND_NAME', '');
define('DIY_BRAND_URL', '');
define('DIY_LINKQQ_PATH', '342210020');
define('DIY_BOTTOM_INFO', '');
?>