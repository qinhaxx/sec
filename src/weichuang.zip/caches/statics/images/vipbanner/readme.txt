Banner 默认图片存放
