<?php
				$__dbhost   = "localhost";

				$__dbname   = "weichuang";

				$__dbuser   = "root";

				$__dbpass   = "";

				$__dbcharset = "utf8";

				$__dbpre    = "es_";

				$__proself    = "/";

			?>