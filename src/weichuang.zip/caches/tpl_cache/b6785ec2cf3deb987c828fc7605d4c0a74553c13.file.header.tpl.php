<?php /* Smarty version Smarty-3.1.18, created on 2017-01-17 22:59:48
         compiled from "C:\1\wamp\www\addons\system\template\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:28527587e3164192580-80102933%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b6785ec2cf3deb987c828fc7605d4c0a74553c13' => 
    array (
      0 => 'C:\\1\\wamp\\www\\addons\\system\\template\\header.tpl',
      1 => 1432976698,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '28527587e3164192580-80102933',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'IMG_PATH' => 0,
    'BASE_NAME' => 0,
    'topmenulists' => 0,
    '_topmenu' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_587e316421b104_64761856',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_587e316421b104_64761856')) {function content_587e316421b104_64761856($_smarty_tpl) {?><div class="header">
    <div class="navbar cf">
        <img class="logo" src="<?php echo $_smarty_tpl->tpl_vars['IMG_PATH']->value;?>
logo.png" alt=""/>
        <h2 class="title">欢迎登录<?php echo $_smarty_tpl->tpl_vars['BASE_NAME']->value;?>
</h2>
        <ul class="nav cf" id="head-nav-menu">
            <li><a class="nav-item-link" href="./">首页</a></li>
            <?php  $_smarty_tpl->tpl_vars['_topmenu'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['_topmenu']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['topmenulists']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['_topmenu']->key => $_smarty_tpl->tpl_vars['_topmenu']->value) {
$_smarty_tpl->tpl_vars['_topmenu']->_loop = true;
?>
                <li><a class="nav-item-link" href="<?php echo $_smarty_tpl->tpl_vars['_topmenu']->value['link'];?>
" href="<?php echo $_smarty_tpl->tpl_vars['_topmenu']->value['target'];?>
"><?php echo $_smarty_tpl->tpl_vars['_topmenu']->value['title'];?>
</a></li>
            <?php }
if (!$_smarty_tpl->tpl_vars['_topmenu']->_loop) {
?>
                <li><a class="nav-item-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank">公司简介</a></li>
                <li><a class="nav-item-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank">产品介绍</a></li>
                <li><a class="nav-item-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank">精品案例</a></li>
                <li><a class="nav-item-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank">行业方案</a></li>
                <li><a class="nav-item-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank">渠道合作</a></li>
                <li><a class="nav-item-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank">联系我们</a></li>
            <?php } ?>
        </ul>
    </div>
</div><?php }} ?>
