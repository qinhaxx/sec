<?php /* Smarty version Smarty-3.1.18, created on 2017-01-17 22:59:48
         compiled from "C:\1\wamp\www\addons\system\template\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29820587e3164226c88-28014545%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '36f18cfd56b3edb20e12fac82b9629d0dde1c083' => 
    array (
      0 => 'C:\\1\\wamp\\www\\addons\\system\\template\\footer.tpl',
      1 => 1432294996,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29820587e3164226c88-28014545',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'JS_PATH' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_587e316423a500_35975686',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_587e316423a500_35975686')) {function content_587e316423a500_35975686($_smarty_tpl) {?><script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['JS_PATH']->value;?>
placeholder.js"></script>
<div class="footer footer-temp"><?php echo @constant('BOTTOM_INFO');?>
</div><?php }} ?>
