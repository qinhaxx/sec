<?php /* Smarty version Smarty-3.1.18, created on 2017-01-17 22:59:48
         compiled from "C:\1\wamp\www\addons\system\template\login.tpl" */ ?>
<?php /*%%SmartyHeaderCode:590587e3164069784-85972029%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd782881fef96f8d1c43bc53a0e7d84ecc1ce8456' => 
    array (
      0 => 'C:\\1\\wamp\\www\\addons\\system\\template\\login.tpl',
      1 => 1455868708,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '590587e3164069784-85972029',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_NAME' => 0,
    'CSS_PATH' => 0,
    'JS_PATH' => 0,
    'settingother' => 0,
    'urlarr' => 0,
    'IMG_PATH' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_587e3164182b89_78713222',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_587e3164182b89_78713222')) {function content_587e3164182b89_78713222($_smarty_tpl) {?>
<!DOCTYPE html>
<html>
<head lang="zh-CN">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>登录界面 - <?php echo $_smarty_tpl->tpl_vars['BASE_NAME']->value;?>
</title>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['CSS_PATH']->value;?>
normalize.css"/>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['CSS_PATH']->value;?>
global.css"/>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['CSS_PATH']->value;?>
alert.css"/>
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['CSS_PATH']->value;?>
font-awesome.css"/>
    <script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['JS_PATH']->value;?>
jquery-1.11.0.js"></script>
    <script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['JS_PATH']->value;?>
jquery.alert.js"></script>
    <script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['JS_PATH']->value;?>
jquery.form.min.js"></script>
</head>
<body>
<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<script>$('#head-nav-menu li:eq(0)').addClass('active');</script>

<div class="wrapper-sign-in"<?php if ($_smarty_tpl->tpl_vars['settingother']->value['loginbg']) {?> style="background-image:url('<?php echo fillurl($_smarty_tpl->tpl_vars['settingother']->value['loginbg']);?>
');"<?php }?>>
    <div class="main-sigh-in cf">
        <div class="sign-in-mod">
            <div class="title">
                <span>账户登录</span>
                <?php if (!@constant('OFF_REG_IS')) {?>
                    <span>|</span>
                    <a class="normal-link" href="<?php echo $_smarty_tpl->tpl_vars['urlarr']->value[2];?>
reg/">注册账户</a>
                <?php }?>
            </div>

            <form action="<?php echo $_smarty_tpl->tpl_vars['urlarr']->value['now'];?>
" method="post" id="loginForm">
                <div class="form-item">
                    <div class="form-group">
                        <input class="form-control" style="width:100%" type="text" name="username" id="username" placeholder="用户名"/>
                    </div>
                </div>
                <div class="form-item">
                    <div class="form-group">
                        <input class="form-control" style="width:100%" type="password" name="userpass" id="userpass" placeholder="密码"/>
                    </div>
                </div>
                <div class="form-item">
                    <input id="subForm" type="submit" class="button button-primary button-metro" value="登录"/>
                    <input type="hidden" name="dosubmit" value="1"/>
                    <a class="normal-link" href="tencent://message/?uin=<?php echo @constant('DIY_LINKQQ_PATH');?>
&Menu=yes">忘记密码？</a>
                </div>
                <div class="form-item">
                    <label><input type="checkbox" id="remember" name="remember"/>记住账号</label>
                    <label><input type="checkbox" id="autoLogin" name="autoLogin"/>下次自动登录</label>
                </div>
            </form>

            <div class="qrcode cf">
                <?php if ($_smarty_tpl->tpl_vars['settingother']->value['logincode']) {?>
                    <img class="image" width="90" src="<?php echo fillurl($_smarty_tpl->tpl_vars['settingother']->value['logincode']);?>
" alt=""/>
                <?php } else { ?>
                    <img class="image" width="90" height="90" src="<?php echo $_smarty_tpl->tpl_vars['IMG_PATH']->value;?>
qrcode.png" alt=""/>
                <?php }?>
                <div class="description">
                    <?php if ($_smarty_tpl->tpl_vars['settingother']->value['logintext']) {?>
                        <?php echo $_smarty_tpl->tpl_vars['settingother']->value['logintext'];?>

                    <?php } else { ?>
                        <p>扫描二维码，关注 <a class="normal-link" href="<?php echo @constant('BRAND_URL');?>
" target="_blank"><?php echo @constant('BRAND_NAME');?>
</a></p>
                        <p>量身定制，随需而变优质产品助您绘制移动互联网时代蓝图</p>
                    <?php }?>
                </div>
            </div>
        </div>
    </div>

</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#loginForm').submit(function() {

            var retu = true;
            retu = $('#loginForm #username').inTips("请输入用户名/邮箱/手机号码", -1, retu);
            retu = $('#loginForm #userpass').inTips("请输入密码", -1, retu);
            if (!retu) return false;

            $.alert('正在登录...', 0);
            $(this).ajaxSubmit({
                dataType : 'json',
                success : function (data) {
                    $.alert(0);
                    if (data != null && data.success != null && data.success) {
                        window.location.href = '<?php echo $_smarty_tpl->tpl_vars['urlarr']->value[2];?>
';
                    } else {
                        $.showModal(data.message);
                    }
                },
                error : function () {
                    $.alert(0);
                    $.inModal("登录失败！");
                }
            });
            return false;
        });
    });
</script>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


</body>
</html><?php }} ?>
