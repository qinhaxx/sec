<?php
define('OFF_SQL_TEMP', '0');
?>