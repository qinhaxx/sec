<?php
define('OFF_SITE_IS', '0');
define('OFF_SITE_WHY', '');
define('OFF_REG_IS', '0');
?>